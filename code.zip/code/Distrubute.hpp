#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wc++17-extensions"
#ifndef DISTRBUTE
#define DISTRBUTE

#include <random>

#include "DfsBlock.hpp"
#include "MaxFlow.hpp"
#include "mem.hpp"

class distributeMethod {
public:
    vector<Method> methods;
    vector<vector<Copoment *>> board_have;
    double lowest_userates = 0;

    double getValue() const {
        return lowest_userates;
    }

    void setValue() {
        lowest_userates = 0;
        for (const auto &method: methods) {
            double use_rate = method.getUseRate();
            lowest_userates += use_rate * use_rate;
        }
    }

    void show() {
        int cnt = 0;
        for (auto method: methods) {
            cout << "in board " << (cnt++) << endl;
            method.show();
            cout << "==========" << endl;
        }
        cout <<" tot value "<< getValue() << endl;
    }
    vector<distributeMethod> neighbor() {
        vector<distributeMethod> distributeMethods;
        assert(methods.size() == board_have.size());
        for (int i = 0; i < methods.size(); i++) {
            if (board_have.empty())
                continue;
            int board_one = i;
            int board_two = rand() % board_have.size();
            if (board_one == board_two)
                continue;
            if (methods[board_one].getUseRate() > 0.99 && methods[board_two].getUseRate() > 0.99) {
                continue;
            }
            int siz = board_have[board_one].size();
            if (siz == 0)
                continue;
            int block_id = rand() % siz;
            auto block = board_have[board_one][block_id];
            distributeMethod new_method = (*this);
            swap(new_method.board_have[board_one][block_id], new_method.board_have[board_one][siz - 1]);
            new_method.board_have[board_two].push_back(block);
            new_method.board_have[board_one].pop_back();
            new_method.methods[board_one] = getDfsMethod(new_method.board_have[board_one]);
            new_method.methods[board_two] = getDfsMethod(new_method.board_have[board_two]);
            new_method.setValue();
            distributeMethods.push_back(new_method);
        }
        return distributeMethods;
    }
    distributeMethod getIterByMaxFlow();
};

vector<Copoment *> pickBlockSumSqrtAs(double sqrt, vector<Copoment *> &pool) {
    vector<Copoment *> best_fit_set;
    double best_dif = sqrt;
    int random_times = 20;
    while (random_times--) {
        /*
         * for random sqrt of block
         * shuffle + greedy will achieve a near best result cmp to DP
         */
        vector<Copoment *> cur_fit_set;
        shuffle(pool.begin(), pool.end(), std::mt19937(std::random_device()()));
        double cur_sqrt = 0;
        for (auto block: pool) {
            if (block->shape.getSqrt() + cur_sqrt < sqrt) {
                cur_sqrt += block->shape.getSqrt();
                cur_fit_set.push_back(block);
            }
        }
        if (sqrt - cur_sqrt < best_dif) {
            best_fit_set = cur_fit_set;
            best_dif = sqrt - cur_sqrt;
        }
    }
    set<Copoment *> erase_list;
    for (auto block: erase_list) {
        erase_list.insert(block);
    }
    vector<Copoment *> new_pool;
    for (auto block: pool) {
        if (erase_list.find(block) == erase_list.end()) {
            new_pool.push_back(block);
        }
    }
    swap(pool, new_pool);
    return best_fit_set;
}

distributeMethod distributeMethod::getIterByMaxFlow() {
    double sqrt = Config::height * Config::width / 3;
    vector<vector<Copoment *>> picked_blocks;
    cout <<" start with sqrt "<< sqrt << endl;
    int cnt = 0;
    for (auto pool: board_have) {
        auto picked_pool = pickBlockSumSqrtAs(sqrt,pool);
        picked_blocks.push_back(picked_pool);
    }
    assert(board_have.size() == picked_blocks.size());
    int board_num = (int) picked_blocks.size();
    int start_point = 0;
    int end_point = board_num * 2 + 1;
    ZKW_MinCostMaxFlow G;
    G.init();
    for (int pick_id = 1; pick_id <= board_num; pick_id++) {
        G.addedge(start_point, pick_id, 1, 0);
    }
    for (int board_id = board_num + 1; board_id <= board_num * 2; board_id++) {
        G.addedge(board_id, end_point, 1, 0);
    }
    for (int pick_id = 1; pick_id <= board_num; pick_id++) {
        for (int board_id = board_num + 1; board_id <= board_num * 2; board_id++) {
            vector<Copoment *> possible_pool(picked_blocks[pick_id - 1]);
            for (auto block: board_have[board_id - (board_num + 1)]) {
                possible_pool.push_back(block);
            }
            Method possible_method = getDfsMethod(possible_pool);
            double use_rate = possible_method.getUseRate();
            int value = (int) (- use_rate * use_rate * 1e3);
            G.addedge(pick_id, board_id, 1, value);
        }
    }
    vector<Match> result = G.getMatch(0, board_num * 2 + 1, board_num * 2 + 2, board_num);
    assert(result.size() == board_num);

    distributeMethod new_distrubute;
    showMemoryInfo();
    for (int i = 0; i < board_num; i++) {
        auto [pick_id, board_id] = result[i];
        cout <<" match "<<pick_id <<" with "<< board_id - board_num << endl;
        vector<Copoment *> new_pool(picked_blocks[pick_id]);
        cout << new_pool.size() <<" " << board_have[board_id - (board_num+1)].size()<< endl;
        for (auto block: board_have[board_id - (board_num + 1)]) {
            new_pool.push_back(block);
        }
        cout <<"start dfs "<< endl;
        Method method = getDfsMethod(new_pool);
        new_distrubute.methods.push_back(method);
        new_distrubute.board_have.push_back(new_pool);
    }
    new_distrubute.setValue();

    new_distrubute.show();
    return new_distrubute;
}


#endif
#pragma clang diagnostic pop